#!/usr/bin/env bash
# Build a Debian package for radiotray-reborn

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VERSION="$(python3 -c "exec(open('${SCRIPT_DIR}/src/radiotray/constants.py').read().split('VERSION')[1].split('\\n')[0]); print(VERSION.strip('\"'))" 2>/dev/null || echo '1.0.0')"

echo "Building radiotray-reborn version ${VERSION}"

# Ensure we're in the project directory
cd "${SCRIPT_DIR}"

# Check for required tools
command -v dpkg-buildpackage >/dev/null 2>&1 || { echo "Error: dpkg-buildpackage not found"; exit 1; }

# Clean previous builds
rm -rf debian/radiotray-reborn
rm -f ../radiotray-reborn_*.deb ../radiotray-reborn_*.buildinfo ../radiotray-reborn_*.changes

# Make debian/rules executable
chmod +x debian/rules

# Build the package
dpkg-buildpackage -us -uc -b

echo ""
echo "Build complete!"
echo "The package can be found in the parent directory."
echo ""
echo "Install with: sudo dpkg -i ../radiotray-reborn_${VERSION}-1_all.deb"
echo ""

# Show the resulting file
ls -lh ../radiotray-reborn_*.deb 2>/dev/null || true
